$ErrorActionPreference='Stop'
$Source=Join-Path $PSScriptRoot 'VST3/Psy303 Bassline.vst3'
$Target=Join-Path $env:CommonProgramFiles 'VST3'
if(!(Test-Path -LiteralPath (Join-Path $Source 'Contents/x86_64-win/Psy303 Bassline.vst3'))){throw 'VST3-Bundle fehlt. ZIP zuerst vollstaendig entpacken.'}
New-Item -ItemType Directory -Force -Path $Target | Out-Null
Copy-Item -LiteralPath $Source -Destination $Target -Recurse -Force
Write-Host "Psy303 Bassline installiert in $Target. Cubase jetzt neu starten."
